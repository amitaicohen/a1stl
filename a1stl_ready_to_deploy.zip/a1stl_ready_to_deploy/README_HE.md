# a1stl — גרסה מוכנה להגדרה ב-Render + Firebase

## הקבצים
- `election_server.py` — שרת שמתחבר ל-Firebase Realtime Database דרך משתני סביבה, ומגיש את האתר מתוך `index.html`.
- `index.html` — קובץ האתר שסופק.
- `requirements.txt` — ספריית Firebase Admin.
- `render.yaml` — הגדרת שירות Render.
- `.gitignore` — הגנה בסיסית מפני העלאת קובצי סודות.

## התקנה (לא להעלות מפתח ל-GitHub)
1. חלץ את ה-ZIP במחשב.
2. במאגר GitHub `amitaicohen/a1stl`, החלף את `election_server.py` ו-`index.html` בגרסאות שבתיקייה. הוסף `requirements.txt` ו-`render.yaml`. אם יש `requirements.txt` קיים, מזג את התלות `firebase-admin>=6.5,<8` במקום לדרוס תלויות אחרות.
3. בצע Commit.
4. היכנס ל-Render, התחבר ל-GitHub, בחר New → Web Service, ובחר במאגר `a1stl`. אפשר להשתמש ב-`render.yaml` או להגדיר ידנית:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python election_server.py`
5. בהגדרות השירות ב-Render → Environment הוסף:
   - `FIREBASE_DATABASE_URL` = כתובת Realtime Database המדויקת שמופיעה ב-Firebase Console.
   - `FIREBASE_SERVICE_ACCOUNT_JSON` = כל תוכן קובץ ה-Service Account JSON כמחרוזת JSON אחת.
6. ב-Firebase Console → Project settings → Service accounts צור private key לשרת. שמור אותו באופן מאובטח; אל תעלה את קובץ ה-JSON ל-GitHub ואל תשלח אותו בצ'אט.
7. בצע Deploy. לאחר פריסה, פתח את כתובת Render. האתר וה-API יהיו באותו מקור, ולכן בקשות `/api/...` יחסיות יפעלו ללא שינוי כתובת.
8. בדוק `/api/results` בכתובת Render; אמור לחזור JSON עם `success`, `votes`, `total_votes`, `voted_count`, `reset_id`.

## בדיקה
- פתח את האתר בכתובת Render.
- הצבע פעם אחת במכשיר בדיקה.
- רענן את `/api/results` ובדוק שהמונה השתנה.
- פתח את האתר במכשיר/דפדפן נוסף וודא שהתוצאה מסונכרנת.

## אזהרות לפני שימוש ציבורי
- בקוד המקורי קיימים קודי מנהל קבועים (`2026` ו-`1234`) ונתיב `/api/admin/inject` שמוסיף הצבעות דמה. יש להסיר/להגן עליהם לפני שימוש ציבורי.
- `threading.Lock` מגן רק בתוך מופע יחיד; כתיבת state מלאה ל-Firebase אינה פעולה אטומית בין מספר מופעי שרת. להשאיר מופע אחד ולשימוש ניסיוני בלבד; שימוש רציני דורש טרנזקציות/כללי הצבעה אטומיים.
- זהו סקר דעת קהל/דמו, לא מערכת בחירות רשמית מאובטחת.
- לא ניתן לאמת את פרטי Firebase או לבצע פריסה בלי גישה לחשבון שלך. אין כאן הבטחה שהפריסה כבר רצה.
